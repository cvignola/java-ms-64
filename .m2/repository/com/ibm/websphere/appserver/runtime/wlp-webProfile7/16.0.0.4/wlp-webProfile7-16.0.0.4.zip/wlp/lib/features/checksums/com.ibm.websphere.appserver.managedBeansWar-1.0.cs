#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.managedBeansWar-1.0.mf=97c9f9b9e4445edc1750e99f68153698
lib/com.ibm.ws.ejbcontainer.war_1.0.15.jar=00fac855fec0677874e5e27bb0a1f7b8
