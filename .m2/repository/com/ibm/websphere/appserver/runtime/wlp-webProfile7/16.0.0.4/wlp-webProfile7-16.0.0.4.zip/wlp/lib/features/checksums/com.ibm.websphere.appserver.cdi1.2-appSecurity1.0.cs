#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.cdi.1.2.security_1.0.15.jar=01e236427725c142d1e01a2de90d4a9c
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurity1.0.mf=5f2e2a799e3cbfda54d459f6a26af48f
