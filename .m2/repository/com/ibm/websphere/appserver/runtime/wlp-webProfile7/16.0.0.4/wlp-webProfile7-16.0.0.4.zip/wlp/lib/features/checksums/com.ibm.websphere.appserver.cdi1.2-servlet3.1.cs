#Sun Nov 13 03:38:16 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.15.jar=bdc0ae70dcc06c3360d80155e3813364
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=31affa0cf97115baedf00bbdb7260712
lib/com.ibm.ws.cdi.1.2.web_1.0.15.jar=e71d7232f8088f7da5f8fd513191712b
