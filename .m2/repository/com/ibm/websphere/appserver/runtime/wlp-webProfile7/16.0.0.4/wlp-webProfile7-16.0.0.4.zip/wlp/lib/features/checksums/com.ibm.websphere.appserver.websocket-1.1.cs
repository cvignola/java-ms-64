#Sun Nov 13 03:38:16 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.15.jar=fbad0df6db342e7a928ceaa171aa54e9
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.15.jar=d86fa8c3d928ec2f890b6cd68a241594
lib/com.ibm.ws.wsoc_1.0.15.jar=cf0f68b4ae23c438e8be16a7d8e2ede4
lib/com.ibm.ws.wsoc.1.1_1.0.15.jar=33128ad8d8ee60c3d87a5ad71cdcca86
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=b6ebdb1e76d20fcd02abbce5e9548a0a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=a815e0fcd3fc1a53de8c2778010290a3
