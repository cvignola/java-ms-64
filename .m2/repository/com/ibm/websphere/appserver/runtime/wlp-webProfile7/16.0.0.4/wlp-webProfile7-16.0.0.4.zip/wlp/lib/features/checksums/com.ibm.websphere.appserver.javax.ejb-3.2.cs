#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=68956c8b5dfe88ebe0c594ee2769d6aa
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.15.jar=457483a20f93f43b1a07aa2c38ebea9e
