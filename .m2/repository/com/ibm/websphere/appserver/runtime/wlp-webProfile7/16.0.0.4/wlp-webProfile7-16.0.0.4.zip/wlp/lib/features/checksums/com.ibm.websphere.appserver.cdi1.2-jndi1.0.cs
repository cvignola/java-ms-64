#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=21de8dde01f89cecfac50c3ed242430e
lib/com.ibm.ws.cdi.1.2.jndi.1.0.0_1.0.15.jar=b19981fdb111f2a879c72555acaa14ac
