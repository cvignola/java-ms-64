#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.15.jar=8a842fef449811ae0bd8b8ff3c155589
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=bd22d62af693c43627a6058fdb44bc47
