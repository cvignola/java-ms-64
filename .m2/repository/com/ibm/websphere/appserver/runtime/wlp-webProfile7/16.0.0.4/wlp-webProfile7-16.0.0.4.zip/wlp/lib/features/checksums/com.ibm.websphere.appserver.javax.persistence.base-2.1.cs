#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.javaee.persistence.2.1_1.0.15.jar=0883fd13951afb3a639884ebafa6ebf9
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=57cf2451cf51eb2e9b6f4a1a99c3196f
