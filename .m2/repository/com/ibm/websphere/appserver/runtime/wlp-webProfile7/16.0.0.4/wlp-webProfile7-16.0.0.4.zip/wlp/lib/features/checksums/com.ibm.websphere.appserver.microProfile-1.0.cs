#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.require.java8_1.0.15.jar=1f0a72b8efd8cc4797e4fdf16db226e9
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=edbbd0ed3fbff7e900cfa071472590f2
