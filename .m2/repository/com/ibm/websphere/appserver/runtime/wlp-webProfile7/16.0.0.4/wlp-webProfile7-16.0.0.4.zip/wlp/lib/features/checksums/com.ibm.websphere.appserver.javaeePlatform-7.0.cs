#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javaeePlatform-7.0.mf=276ad235c60ed7a338e41a887cb12953
lib/com.ibm.ws.javaee.version_1.0.15.jar=6d9fe92cedf557ed795bbca08ce02144
lib/com.ibm.ws.javaee.platform.v7_1.0.15.jar=dda7ea7e9a79e020ebdc7c24e5b4df4c
lib/com.ibm.ws.javaee.platform.defaultresource_1.0.15.jar=ae79f07d1be75d616c1f085597e3011a
