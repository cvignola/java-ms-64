#Sun Nov 13 03:38:16 GMT 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security_1.2-javadoc.zip=55782e0f7497975069a1478bf5a64c6c
lib/com.ibm.ws.management.security_1.0.15.jar=1a1a8060a17c5ba864d73866bdad4673
dev/api/ibm/com.ibm.websphere.appserver.api.security_1.2.15.jar=72e12be9a9e413d78dc90da5572e6b7a
lib/com.ibm.websphere.security.impl_1.0.15.jar=e028863f982e2dfc51e7e395ac0137ac
lib/features/com.ibm.websphere.appserver.security-1.0.mf=3230a4a0034f6934ea74b0d210869c45
lib/com.ibm.ws.security.quickstart_1.0.15.jar=39530b6a4bda03d872f390e267c67dce
