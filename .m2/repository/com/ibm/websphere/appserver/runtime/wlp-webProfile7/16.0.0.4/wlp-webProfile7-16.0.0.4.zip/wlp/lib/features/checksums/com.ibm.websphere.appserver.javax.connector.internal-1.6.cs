#Sun Nov 13 03:38:15 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.15.jar=8f452f4f3610edad38dfe60bc9290d31
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=104bf7891ab01c0fbb2862b2b44253ef
