#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.security.context_1.0.15.jar=2005d2a5e14af865ecafad0e8421dd2b
lib/features/com.ibm.websphere.appserver.securityContext-1.0.mf=5688aefcc2c6b794fb04161555248c2b
