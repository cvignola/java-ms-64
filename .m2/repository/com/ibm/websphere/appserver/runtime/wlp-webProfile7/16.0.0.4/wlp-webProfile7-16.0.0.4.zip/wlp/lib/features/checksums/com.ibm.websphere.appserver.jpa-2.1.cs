#Sun Nov 13 03:38:15 GMT 2016
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.15.jar=fee17fcbf4fd1bcde7a114ea0287dca3
lib/com.ibm.ws.jpa.container_1.0.15.jar=2ac5c0b09e37f74f3e4e694813ddc200
lib/com.ibm.ws.jpa.container.v21_1.0.15.jar=37bbd00776b94230c7133197713dbca4
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=6be20cd0c920cfbf892a77e4a77d413b
lib/com.ibm.ws.jpa.container.eclipselink_1.0.15.jar=65a242845164f71ba9b526b7d64feecb
