#Sun Nov 13 03:38:15 GMT 2016
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.15.jar=7e92ce7a4c3480ff1698dce913366a6e
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=43efdc23a763c9246c677a2d8daaf1f6
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.15.jar=8e65fc9692e7d615cb03056331bf7673
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=3d9dca6b66d8016ba148ccc9ce883f32
