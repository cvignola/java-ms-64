#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.managedBeansCore-1.0.mf=cb8d048bf02d56b9d56768026e16ea9e
lib/com.ibm.ws.javaee.dd.ejb_1.1.15.jar=b81621ce4603ff859e319f7e26f514ae
lib/com.ibm.ws.ejbcontainer_1.0.15.jar=03ebbae9d86c92c89f50d4643af13d13
lib/com.ibm.ws.jaxrpc.stub_1.1.15.jar=394b78165424d20e14abac6fa52717f8
lib/com.ibm.ws.managedobject_1.0.15.jar=957b998512bdc113ef8ef31f8a5ad07e
