#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.15.jar=4e222701de7bb5499e13f9c865c3ad98
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=c0789610278170d4b29548ead8dab6f6
