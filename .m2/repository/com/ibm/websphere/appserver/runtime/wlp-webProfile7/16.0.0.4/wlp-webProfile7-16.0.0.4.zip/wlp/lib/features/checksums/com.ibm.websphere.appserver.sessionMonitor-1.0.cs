#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.session.monitor_1.0.15.jar=d33d1b5829ff334e32aca8d843fb5273
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.15.jar=08121bbfbd0d3a565b5e41e2108bd1a5
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=b688bafddfefef3b0d9e9f493cf9c6ff
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=36a45c4dcf8167d4e17b99fd4e2c2673
