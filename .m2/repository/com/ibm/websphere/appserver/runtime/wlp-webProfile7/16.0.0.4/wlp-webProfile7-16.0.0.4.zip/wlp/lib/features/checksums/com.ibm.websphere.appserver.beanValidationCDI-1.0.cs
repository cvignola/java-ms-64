#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.15.jar=22d2e435711e67f21c128198e6ba94cc
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=4ca995f861e45406b48f5be373f2e456
