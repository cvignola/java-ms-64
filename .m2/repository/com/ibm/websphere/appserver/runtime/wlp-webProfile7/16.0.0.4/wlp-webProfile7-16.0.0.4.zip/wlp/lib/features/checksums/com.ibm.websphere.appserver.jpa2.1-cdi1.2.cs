#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.15.jar=9003753d4c335a7c040d98c64c8707ec
lib/features/com.ibm.websphere.appserver.jpa2.1-cdi1.2.mf=db65fc872bd11c74640510aeb0c5e583
