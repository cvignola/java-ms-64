#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=51e4bdc0696bf613e307a2eacebf3fd2
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.15.jar=84d635c185338550d0fae119044a84ed
