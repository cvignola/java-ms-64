#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.jdbc-4.1.mf=b0bc1d8014f9eb1b6ad5c6f375ff37cb
lib/com.ibm.ws.jdbc_1.0.15.jar=8993e83171c7c0c15621f5add45e31f9
lib/com.ibm.ws.jdbc.4.1_1.0.15.jar=f8f3725b2d3747281b62d929eaec045e
