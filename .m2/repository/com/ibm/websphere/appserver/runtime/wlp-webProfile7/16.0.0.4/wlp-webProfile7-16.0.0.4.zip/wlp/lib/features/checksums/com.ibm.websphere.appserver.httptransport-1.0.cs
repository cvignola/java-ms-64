#Sun Nov 13 03:38:15 GMT 2016
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.1-javadoc.zip=5d38d9458417f3fd4eff5cf8195b8863
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.1.15.jar=edca6cfebab8c1bff269a672200774e7
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=3bdf94289c3477e0bcc66ce57865f807
lib/com.ibm.ws.transport.http_1.0.15.jar=57c3de4ee4625b93adcc55a66f499aeb
