#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=b88dc8b373c0c87353bc39ffdc71c1e0
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.15.jar=3d3ed7f44c24117956839120f5e8b034
