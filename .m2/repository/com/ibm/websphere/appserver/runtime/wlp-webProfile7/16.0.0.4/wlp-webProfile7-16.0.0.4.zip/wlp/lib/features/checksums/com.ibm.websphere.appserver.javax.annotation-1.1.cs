#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=bf6dcadfe441362fd60e8ea6fba17156
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.15.jar=94eb21f18d55484d250a236fc406a758
