#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=b8aef15edd99ac1c1f72e49fa81776de
dev/api/spec/com.ibm.websphere.javaee.ejb.3.1_1.0.15.jar=c8d89a34cee36c1eacc51fbb12a95316
