#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=fc7745e3eda94e3de72c2ceb40a4bf3b
lib/com.ibm.ws.injection_1.0.15.jar=ab5fb7cd31bff2a4d519a3c67b2ad001
