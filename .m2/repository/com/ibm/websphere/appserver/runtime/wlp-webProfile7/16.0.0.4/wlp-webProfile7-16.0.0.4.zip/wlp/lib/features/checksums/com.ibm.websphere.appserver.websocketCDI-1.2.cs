#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=5864fc67ea503801031f11d8cf9ae10f
lib/com.ibm.ws.wsoc.cdi.weld_1.0.15.jar=5ddb97475ee8299de920b807ca9e0d25
