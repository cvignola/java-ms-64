#Sun Nov 13 03:38:16 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.15.jar=f3eb462d4211b988c57e8240352e90f5
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.15.jar=7e92ce7a4c3480ff1698dce913366a6e
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=da8a013aaebc8881f1748a049d890e4a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=3d9dca6b66d8016ba148ccc9ce883f32
