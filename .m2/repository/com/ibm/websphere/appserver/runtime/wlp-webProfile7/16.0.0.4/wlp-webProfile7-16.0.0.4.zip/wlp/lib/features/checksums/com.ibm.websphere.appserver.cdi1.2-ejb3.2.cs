#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.cdi.1.2.ejb_1.0.15.jar=75a683cc2175a1c06357a4d0d473f8bd
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=bea36346b4e1132e42a74e5d508b2d75
