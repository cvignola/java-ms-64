#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=665c3e84e58b2b70bded4629ef72cdda
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=8b2e62162726a3106f8df8f1e93d8ad8
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.15.jar=0aa26c7d86d82f7437e68b2a94cd61a0
lib/com.ibm.ws.connectionpool.monitor_1.0.15.jar=532fd63e23a8b27cab59d9e9cfd4106d
