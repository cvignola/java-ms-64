#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=cd101b298991b40478971087cb7565ec
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.15.jar=dca4bbefe07e138770d25bed491af0b5
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.15.jar=ecd13534750c343244b5fcb90d8d61cd
