#Sun Nov 13 03:38:16 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.15.jar=0748a7f1c9cf49e9927cff962a964226
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=ec99970f48cd84060f12dc5169f4f0cc
