#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=388c9d4181df33eb7bd4300e584d7ac5
lib/com.ibm.ws.dynamic.bundle_1.0.15.jar=9902f07b00a548a54711f13cfb25b63a
