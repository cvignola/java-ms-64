#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=f4eea60a5839182e150c342a76399324
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.15.jar=aa7a3329c5d9f8e99ee59453c72090d2
