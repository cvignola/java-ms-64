#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.jaxrs.2.0.security_1.0.15.jar=8cd0895f9bca0c536500aeb14a2fa36e
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=c44130d14f25fdb7d6b6b8b6fd96d595
