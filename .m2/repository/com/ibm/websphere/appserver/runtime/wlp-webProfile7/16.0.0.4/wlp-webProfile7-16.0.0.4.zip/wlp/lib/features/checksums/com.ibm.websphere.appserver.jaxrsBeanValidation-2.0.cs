#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.15.jar=4e18374f91dfa7951ae2ef5133dc9005
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=df5fb9d1bc96d72ab35a9f8a0376e17c
