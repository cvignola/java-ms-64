#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.transaction-1.1.mf=f260f69c52f52b6592a96c815f7b2e9f
lib/com.ibm.tx.util_1.0.15.jar=a614cb1f467842ea993c30057de3e3e1
lib/com.ibm.ws.tx.jta.extensions_1.0.15.jar=db1e117a9c6b8752eb46a7470ed11670
lib/com.ibm.ws.recoverylog_1.0.15.jar=c1137f9b95ab0ce421121d328c5c4193
lib/com.ibm.rls.jdbc_1.0.15.jar=906a159d424c71869f85dc9020d38b26
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.15.jar=b2b7e21a7841bf76d6d65f99ede5c6e2
lib/com.ibm.ws.transaction_1.0.15.jar=f62da3929f494eda640ee72e0cfe1ceb
lib/com.ibm.tx.jta_1.0.15.jar=ad60d8df829339e5cea6e76d7431a509
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=8531fd1773076fffbec380eb3583e907
lib/com.ibm.ws.tx.embeddable_1.0.15.jar=1cffa5b61e69f5f4312f30177a3237cb
lib/com.ibm.tx.ltc_1.0.15.jar=3eaa468308967ef813f8f68e13782ff1
