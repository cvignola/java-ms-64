#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=d2abfcc422a6eb82b1e03c4db30e70d7
lib/com.ibm.ws.cdi.1.2.transaction_1.0.15.jar=118cbb3a0cbf8808da215e6aa549e1e2
