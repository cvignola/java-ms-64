#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=12c6b8b043f9556482be6cb1da789941
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.15.jar=5fbf39a9cb7c2c2f51f4323f2eea0edb
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.15.jar=7b537c3a577b8459f9183b760c87fab0
