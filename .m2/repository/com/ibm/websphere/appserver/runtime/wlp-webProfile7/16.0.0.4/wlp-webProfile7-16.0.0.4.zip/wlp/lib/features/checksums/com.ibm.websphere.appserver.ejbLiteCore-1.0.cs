#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=7956642db736d35aa0f3aa9ac264219b
lib/com.ibm.ws.ejbcontainer.session_1.0.15.jar=7c2a8c69e9e16783341cc067f437b1e0
