#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.json-1.0.mf=ebbdf40f02ac0b41d4f1ac444c91f4e8
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
lib/com.ibm.json4j_1.0.15.jar=26b026658543cc6717dde7b0cee44ce1
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.15.jar=5c529022d985900e745182ef8fa256be
