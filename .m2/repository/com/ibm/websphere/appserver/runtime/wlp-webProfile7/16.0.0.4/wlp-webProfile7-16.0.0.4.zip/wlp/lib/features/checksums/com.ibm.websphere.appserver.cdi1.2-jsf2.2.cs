#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=0e1cd2e11440cadf3ab40205b84d4897
lib/com.ibm.ws.cdi.1.2.jsf_1.0.15.jar=1cb46a99811cc19cbf0be45a531e50f3
