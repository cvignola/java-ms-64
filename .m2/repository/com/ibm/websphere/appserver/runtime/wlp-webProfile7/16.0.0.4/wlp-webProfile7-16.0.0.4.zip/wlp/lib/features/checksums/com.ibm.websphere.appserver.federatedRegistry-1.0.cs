#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.websphere.security_1.0.15.jar=4eca7e4b3ac0c5742c8b7c11913b955a
lib/com.ibm.ws.security.registry_1.0.15.jar=7ed2e332d5f92c1068ae6831e2e8a8e6
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.federatedRepository_1.0-javadoc.zip=cf2060febeba8c0c4494c075f204bd71
lib/features/com.ibm.websphere.appserver.federatedRegistry-1.0.mf=8854e955a00667a39ef7c52b45c3c5a2
lib/com.ibm.ws.security.wim.registry_1.0.15.jar=4f36e5902f0640faa8568b3c062af4b4
dev/spi/ibm/com.ibm.websphere.appserver.spi.federatedRepository_1.0.15.jar=0e4be532519b80b74dc930aa15f1fb42
