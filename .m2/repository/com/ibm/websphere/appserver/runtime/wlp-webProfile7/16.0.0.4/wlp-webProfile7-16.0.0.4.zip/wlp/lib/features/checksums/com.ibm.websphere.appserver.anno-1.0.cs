#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=09706c848c6a4f5fe128e625ffbef1be
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=83d30a22208973070cc9fd8a322bc7d9
lib/com.ibm.ws.anno_1.0.15.jar=35869bc41586d8f8240400ef4361f014
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.15.jar=f0bae69e6a6fe6b009c46bf35a59757d
