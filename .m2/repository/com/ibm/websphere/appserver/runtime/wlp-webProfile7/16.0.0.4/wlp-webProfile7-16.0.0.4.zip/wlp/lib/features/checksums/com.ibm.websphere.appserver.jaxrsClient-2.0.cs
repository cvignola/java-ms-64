#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.jaxrs.2.0.client_1.0.15.jar=a3d9cd056ce60830d0162dc5a3b5b2ac
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=030561fecae31cc8030b30640b210760
