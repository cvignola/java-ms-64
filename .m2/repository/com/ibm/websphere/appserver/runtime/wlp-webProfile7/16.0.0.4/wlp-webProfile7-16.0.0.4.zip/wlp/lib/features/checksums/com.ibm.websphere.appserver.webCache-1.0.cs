#Sun Nov 13 03:38:15 GMT 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.webCache_1.1-javadoc.zip=b33b8119288b23bf5ec8603320fd3fe4
dev/api/ibm/com.ibm.websphere.appserver.api.webCache_1.1.15.jar=4e9d2f037e7b059332d068cfd6a7f5fe
lib/com.ibm.ws.dynacache.web_1.0.15.jar=11db0efc80178247e37e048d42cb4006
dev/spi/ibm/com.ibm.websphere.appserver.spi.webCache_1.0.15.jar=fc97e78a2ba8032044adf87e1cb457ae
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.webCache_1.0-javadoc.zip=44c1e8dbbd63e5677c1345ea865c3a93
dev/api/ibm/schema/cachespec.xsd=4c363b074382cb0c1762f596c91bdfa4
lib/features/com.ibm.websphere.appserver.webCache-1.0.mf=227c6be9ccf1827227d6785fba66e2f3
