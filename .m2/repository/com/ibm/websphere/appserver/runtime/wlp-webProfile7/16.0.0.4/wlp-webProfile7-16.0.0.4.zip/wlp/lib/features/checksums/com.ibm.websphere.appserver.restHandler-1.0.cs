#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.websphere.rest.handler_1.0.15.jar=f18f790f5560b873f407791e7f703ec1
lib/com.ibm.ws.rest.handler_1.0.15.jar=7899fd005436cb0a14f256da05fa3fa2
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_1.5-javadoc.zip=1454ab2ddc9a130c019b0fcc4fd61ad2
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_1.5.15.jar=3877f1c18d3dec6d2ee8af2a14eb9dac
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.15.jar=14c700a48b17b89cbb4517ac0266d88c
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=0301309bae3bd8271a5b1f2a26298e08
lib/com.ibm.websphere.rest.api.discovery_1.0.15.jar=8565204be5cb017eaf8c1b32926f1a4d
lib/com.ibm.websphere.collective.plugins_1.0.15.jar=60279e1acba0dfa5620277b8f5023a9a
lib/com.ibm.websphere.jsonsupport_1.0.15.jar=06d116309401bc7a0ffe6fd8c0eae9bb
