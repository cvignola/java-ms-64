#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.restConnectorjaxrs20-1.0.mf=e3c5b37cdf585471389b9bcc2582bc60
