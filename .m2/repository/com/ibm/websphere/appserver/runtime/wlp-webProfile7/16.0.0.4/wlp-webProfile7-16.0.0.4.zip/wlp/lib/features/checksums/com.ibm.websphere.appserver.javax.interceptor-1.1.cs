#Sun Nov 13 03:38:15 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.15.jar=d9852e55b905eacf97be5a1238600abc
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=75f7d982bf3f26e1242684f102988feb
