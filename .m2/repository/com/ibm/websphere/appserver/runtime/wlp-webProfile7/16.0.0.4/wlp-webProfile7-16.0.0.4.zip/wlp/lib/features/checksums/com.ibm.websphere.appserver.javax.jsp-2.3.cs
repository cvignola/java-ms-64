#Sun Nov 13 03:38:15 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.15.jar=bdc0ae70dcc06c3360d80155e3813364
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=e6e863c205adbd99d2fe8f1ba00a1aec
