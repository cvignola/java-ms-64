#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.validation-1.1.mf=b161a552d461979234d394cf9c8d8b94
dev/api/spec/com.ibm.websphere.javaee.validation.1.1_1.0.15.jar=0cbdf7d74aae1eb05fe4d4ef94ca3c1b
