#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.15.jar=fe9a00bfc7084615890bb323f38e9a77
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=7bdf963580261ecfafa0768caaa50d5c
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.15.jar=28a133c3298e816845c6a95fe7a6855f
