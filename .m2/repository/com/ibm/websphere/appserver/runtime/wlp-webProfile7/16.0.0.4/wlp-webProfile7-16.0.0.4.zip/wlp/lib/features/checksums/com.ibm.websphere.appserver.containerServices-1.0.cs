#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.containerServices-1.0.mf=5857c28acfdb2ed45011795003ae86e5
lib/com.ibm.ws.javaee.version_1.0.15.jar=6d9fe92cedf557ed795bbca08ce02144
lib/com.ibm.ws.serialization_1.0.15.jar=e938df28876c3218f435d48cc5ff02e2
lib/com.ibm.ws.container.service_1.0.15.jar=ca67617d90cc1ea12f8a07b39b965296
dev/spi/ibm/com.ibm.websphere.appserver.spi.containerServices_2.0.15.jar=f094e4358f792a2c3c986db38edc9cf9
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.containerServices_2.0-javadoc.zip=0c695572361687ed121001043d38c0e9
lib/com.ibm.ws.resource_1.0.15.jar=5818f5dc0fd968af79acbd057ab6f562
