#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=804f0cd9fbb33247ab5693fef3b318e4
lib/com.ibm.ws.ejbcontainer.jpa_1.0.15.jar=dd4f696001c5882b0d61a2251263aa69
