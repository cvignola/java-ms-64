#Sun Nov 13 03:38:15 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.servlet.3.0_1.0.15.jar=0008ac749da31f807f0edc4cd8858c6f
lib/features/com.ibm.websphere.appserver.javax.servlet-3.0.mf=cf4898126370f4daba606d9bf46cf236
