#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.internal.jaxrs-2.0.mf=7c22ca043fe32332ce65418d83a48f8c
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.15.jar=66479bdb4063154968f162738524ca89
lib/com.ibm.ws.jaxrs.2.0.client_1.0.15.jar=a3d9cd056ce60830d0162dc5a3b5b2ac
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.15.jar=04792d8762bf42e74a32b3befbdf8910
lib/com.ibm.ws.jaxrs.2.0.server_1.0.15.jar=dd6a9d67290f29870de4b0779ee53839
lib/com.ibm.ws.jaxrs.2.0.web_1.0.15.jar=e47f5856cb7c523489ad2417b95480fd
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.15.jar=8ac67d0ceaed1be038853f4c9a80a6fe
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=c3c8125fdcc5d04419096d3cc46e645e
lib/com.ibm.ws.org.apache.xml.resolver.1.2_1.0.15.jar=6b79400ccd507e1720a39be43db77e4c
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.15.jar=71a5864f8963799569acaf320e53767b
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.15.jar=e1e2d5bfb180126552f1503de439ccd6
bin/jaxrs/tools/wadl2java.jar=965f92a16b8941d4d462687beddb6169
lib/com.ibm.ws.jaxrs.2.0.common_1.0.15.jar=b8f141874f1ce7992014448b0841b3e2
