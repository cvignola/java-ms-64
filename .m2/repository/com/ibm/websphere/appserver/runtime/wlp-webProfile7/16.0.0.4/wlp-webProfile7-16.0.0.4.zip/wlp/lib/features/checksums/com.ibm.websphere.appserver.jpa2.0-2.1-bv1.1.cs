#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=cae879fe8c773bf048a17fa4eb1d786a
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.15.jar=c99adcacd3b78f3945edec9e2af1955a
