#Sun Nov 13 03:38:15 GMT 2016
lib/com.ibm.ws.tx.zos_1.0.15.jar=1b38ef06256c1a5a42727be617e1be27
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=9f8ce032050ef94f295b8f2dd6e96dfe
lib/com.ibm.ws.jca.cm_1.0.15.jar=3dae78a9ab5449407ce17de850ada069
