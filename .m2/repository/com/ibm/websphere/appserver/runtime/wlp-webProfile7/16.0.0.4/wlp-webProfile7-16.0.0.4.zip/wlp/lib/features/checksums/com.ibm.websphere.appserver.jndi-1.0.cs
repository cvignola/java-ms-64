#Sun Nov 13 03:38:16 GMT 2016
lib/com.ibm.ws.org.apache.aries.jndi.core.1.0.3_1.1.15.jar=0708357f0c679abbdfe38d7bdea90551
lib/com.ibm.ws.jndi.url.contexts_1.0.15.jar=f5bc1304fcdb335eb2e1c53e85cf47dd
lib/com.ibm.ws.org.apache.aries.jndi.api.1.1.1_1.1.15.jar=e0bf2063932fa7bb6c56d9aef097a239
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=78aa2a3c8b7aecf4b471a306477213bf
lib/com.ibm.ws.jndi_1.0.15.jar=c8413b1314777e36d32b599a4c907e83
