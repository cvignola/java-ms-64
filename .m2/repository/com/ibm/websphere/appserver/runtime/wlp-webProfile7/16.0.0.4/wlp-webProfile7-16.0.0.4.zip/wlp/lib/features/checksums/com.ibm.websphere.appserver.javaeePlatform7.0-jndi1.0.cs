#Sun Nov 13 03:38:16 GMT 2016
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=d70c8ebd4a7cacfd9da52d33854563c0
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.15.jar=fbfc96779c02c6ef6e164122845c29c0
