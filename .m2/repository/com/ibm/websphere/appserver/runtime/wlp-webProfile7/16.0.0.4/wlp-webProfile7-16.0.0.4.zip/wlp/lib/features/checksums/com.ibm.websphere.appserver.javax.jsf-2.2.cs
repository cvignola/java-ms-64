#Sun Nov 13 03:38:15 GMT 2016
lib/features/com.ibm.websphere.appserver.javax.jsf-2.2.mf=5c2688bf41f6aaad37b8096c30373c9a
dev/api/spec/com.ibm.websphere.javaee.jsf.2.2_1.0.15.jar=1a8136f2f4f83f22441080c16b066a73
