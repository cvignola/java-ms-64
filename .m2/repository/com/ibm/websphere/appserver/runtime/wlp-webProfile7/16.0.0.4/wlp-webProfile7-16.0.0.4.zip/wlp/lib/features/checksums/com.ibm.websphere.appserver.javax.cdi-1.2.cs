#Sun Nov 13 03:38:15 GMT 2016
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.15.jar=055882836ac5b895831be68859062056
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=3f23ebe4558b8ef55e8f6ad31f4ace28
